_________________________________________________________________________

        Readme.TXT File (InterAct DexPlorer - Ver.2.00)
                            January 2000	
_________________________________________________________________________
1.  	Setup
1.1 	This version of InterAct DexPlorer can be used under the following OS:
		Windows 95
		Windows 98
		Windows NT4.0 (Require Service Pack 3 or later and Internet 
                               Explorer Version 4 or later)

2.	Usage of AC adapter
	It is recommended to use AC adapter with the DexDrive (especially, while 
        used with the following memory cards) whenever you find abnormal behavior 
        such as failure to detect memory card or failure to perform read/write 
        operation properly. 
        a. All cards with LED display              
        b. All cards which contain more than one page              

3.      Remark of using feature "Changing page through Software Control"
        [This feature can only be used with memory card of Sony Playstation]
3.1     The feature of changing pages through software control can only be
        used if the memory card is a multi-page memory card and there is no 
        hardware button on the memory card to change the page.

3.2	Depending on how many pages of a multi-page memory card have been used
        for data storage, the time to change a page through software control
        may take time from 10 seconds to 120 seconds.

3.3	While pressing hardware button of the following memory cards to change 
        page, please wait until the small "w" character in the LCD panel 
        disappears. This operation may take some time and DexPlorer will indicate 
        status of "memory card not found".
	a. InterAct MEGA Memory Card (SV-1110, SV-1110A)
_________________________________________________________________________
