This is a batch file and exe file made by me, Ximeter, with the help of with the sram upload
utility 1.1, which, I believe was made by LaC.

It's purpose is to convert EEPROM save files from Dexchange.net into v64 loadable save 
files.

This Exe will take two pages of data from the first file in a Dexplorer .N64 file (if you
don't have Dexplorer, you can download it from dexchange.net).
By putting a Dexplorer EEPROM save all by itself in a .N64 file and using this utility
on it, you can extract that data to a .sav file.

I have included the Sram Upload utility with this zip file so that the .sav file can
be converted to a V64 loadable file.

To simplify the process, a batch file is also included which will do the entire process 
starting from a dexplorer file named "saveload.n64", so, if you use this file for the 
extraction process, it can all be automatically loaded into up-sram.v64 via the use of 
dex2sav.bat .

-Ximeter
ximeter@usa.net

