These usually go in your c:\windows\system32\  or c:\winnt\system32\  directory, depending on your OS.
